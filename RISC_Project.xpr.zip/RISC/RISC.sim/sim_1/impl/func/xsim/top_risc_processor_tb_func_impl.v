// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
// Date        : Mon Aug  3 22:25:03 2026
// Host        : AsusTUFgaming running 64-bit major release  (build 9200)
// Command     : write_verilog -mode funcsim -nolib -force -file
//               C:/Users/aditya/RISC/RISC.sim/sim_1/impl/func/xsim/top_risc_processor_tb_func_impl.v
// Design      : top_risc_processor
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module EX_MEM
   (RegWrite_out_reg_0,
    Q,
    RegWrite_out,
    clk_IBUF_BUFG,
    reset_IBUF,
    D);
  output RegWrite_out_reg_0;
  output [31:0]Q;
  input RegWrite_out;
  input clk_IBUF_BUFG;
  input reset_IBUF;
  input [31:0]D;

  wire [31:0]D;
  wire [31:0]Q;
  wire RegWrite_out;
  wire RegWrite_out_reg_0;
  wire clk_IBUF_BUFG;
  wire reset_IBUF;

  FDCE #(
    .INIT(1'b0)) 
    \MEM_ALU_Result_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[0]),
        .Q(Q[0]));
  FDCE #(
    .INIT(1'b0)) 
    \MEM_ALU_Result_reg[10] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[10]),
        .Q(Q[10]));
  FDCE #(
    .INIT(1'b0)) 
    \MEM_ALU_Result_reg[11] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[11]),
        .Q(Q[11]));
  FDCE #(
    .INIT(1'b0)) 
    \MEM_ALU_Result_reg[12] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[12]),
        .Q(Q[12]));
  FDCE #(
    .INIT(1'b0)) 
    \MEM_ALU_Result_reg[13] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[13]),
        .Q(Q[13]));
  FDCE #(
    .INIT(1'b0)) 
    \MEM_ALU_Result_reg[14] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[14]),
        .Q(Q[14]));
  FDCE #(
    .INIT(1'b0)) 
    \MEM_ALU_Result_reg[15] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[15]),
        .Q(Q[15]));
  FDCE #(
    .INIT(1'b0)) 
    \MEM_ALU_Result_reg[16] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[16]),
        .Q(Q[16]));
  FDCE #(
    .INIT(1'b0)) 
    \MEM_ALU_Result_reg[17] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[17]),
        .Q(Q[17]));
  FDCE #(
    .INIT(1'b0)) 
    \MEM_ALU_Result_reg[18] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[18]),
        .Q(Q[18]));
  FDCE #(
    .INIT(1'b0)) 
    \MEM_ALU_Result_reg[19] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[19]),
        .Q(Q[19]));
  FDCE #(
    .INIT(1'b0)) 
    \MEM_ALU_Result_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[1]),
        .Q(Q[1]));
  FDCE #(
    .INIT(1'b0)) 
    \MEM_ALU_Result_reg[20] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[20]),
        .Q(Q[20]));
  FDCE #(
    .INIT(1'b0)) 
    \MEM_ALU_Result_reg[21] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[21]),
        .Q(Q[21]));
  FDCE #(
    .INIT(1'b0)) 
    \MEM_ALU_Result_reg[22] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[22]),
        .Q(Q[22]));
  FDCE #(
    .INIT(1'b0)) 
    \MEM_ALU_Result_reg[23] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[23]),
        .Q(Q[23]));
  FDCE #(
    .INIT(1'b0)) 
    \MEM_ALU_Result_reg[24] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[24]),
        .Q(Q[24]));
  FDCE #(
    .INIT(1'b0)) 
    \MEM_ALU_Result_reg[25] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[25]),
        .Q(Q[25]));
  FDCE #(
    .INIT(1'b0)) 
    \MEM_ALU_Result_reg[26] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[26]),
        .Q(Q[26]));
  FDCE #(
    .INIT(1'b0)) 
    \MEM_ALU_Result_reg[27] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[27]),
        .Q(Q[27]));
  FDCE #(
    .INIT(1'b0)) 
    \MEM_ALU_Result_reg[28] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[28]),
        .Q(Q[28]));
  FDCE #(
    .INIT(1'b0)) 
    \MEM_ALU_Result_reg[29] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[29]),
        .Q(Q[29]));
  FDCE #(
    .INIT(1'b0)) 
    \MEM_ALU_Result_reg[2] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[2]),
        .Q(Q[2]));
  FDCE #(
    .INIT(1'b0)) 
    \MEM_ALU_Result_reg[30] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[30]),
        .Q(Q[30]));
  FDCE #(
    .INIT(1'b0)) 
    \MEM_ALU_Result_reg[31] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[31]),
        .Q(Q[31]));
  FDCE #(
    .INIT(1'b0)) 
    \MEM_ALU_Result_reg[3] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[3]),
        .Q(Q[3]));
  FDCE #(
    .INIT(1'b0)) 
    \MEM_ALU_Result_reg[4] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[4]),
        .Q(Q[4]));
  FDCE #(
    .INIT(1'b0)) 
    \MEM_ALU_Result_reg[5] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[5]),
        .Q(Q[5]));
  FDCE #(
    .INIT(1'b0)) 
    \MEM_ALU_Result_reg[6] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[6]),
        .Q(Q[6]));
  FDCE #(
    .INIT(1'b0)) 
    \MEM_ALU_Result_reg[7] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[7]),
        .Q(Q[7]));
  FDCE #(
    .INIT(1'b0)) 
    \MEM_ALU_Result_reg[8] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[8]),
        .Q(Q[8]));
  FDCE #(
    .INIT(1'b0)) 
    \MEM_ALU_Result_reg[9] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[9]),
        .Q(Q[9]));
  FDCE #(
    .INIT(1'b0)) 
    RegWrite_out_reg
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(RegWrite_out),
        .Q(RegWrite_out_reg_0));
endmodule

module ID_EX
   (RegWrite_out,
    clk_IBUF_BUFG,
    reset_IBUF);
  output RegWrite_out;
  input clk_IBUF_BUFG;
  input reset_IBUF;

  wire RegWrite_out;
  wire clk_IBUF_BUFG;
  wire reset_IBUF;

  FDCE #(
    .INIT(1'b0)) 
    RegWrite_out_reg
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(1'b1),
        .Q(RegWrite_out));
endmodule

module MEM_WB
   (RegWrite_out,
    Q,
    RegWrite_out_reg_0,
    clk_IBUF_BUFG,
    reset_IBUF,
    D);
  output RegWrite_out;
  output [31:0]Q;
  input RegWrite_out_reg_0;
  input clk_IBUF_BUFG;
  input reset_IBUF;
  input [31:0]D;

  wire [31:0]D;
  wire [31:0]Q;
  wire RegWrite_out;
  wire RegWrite_out_reg_0;
  wire clk_IBUF_BUFG;
  wire reset_IBUF;

  FDCE #(
    .INIT(1'b0)) 
    RegWrite_out_reg
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(RegWrite_out_reg_0),
        .Q(RegWrite_out));
  FDCE #(
    .INIT(1'b0)) 
    \WB_ALU_Result_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[0]),
        .Q(Q[0]));
  FDCE #(
    .INIT(1'b0)) 
    \WB_ALU_Result_reg[10] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[10]),
        .Q(Q[10]));
  FDCE #(
    .INIT(1'b0)) 
    \WB_ALU_Result_reg[11] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[11]),
        .Q(Q[11]));
  FDCE #(
    .INIT(1'b0)) 
    \WB_ALU_Result_reg[12] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[12]),
        .Q(Q[12]));
  FDCE #(
    .INIT(1'b0)) 
    \WB_ALU_Result_reg[13] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[13]),
        .Q(Q[13]));
  FDCE #(
    .INIT(1'b0)) 
    \WB_ALU_Result_reg[14] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[14]),
        .Q(Q[14]));
  FDCE #(
    .INIT(1'b0)) 
    \WB_ALU_Result_reg[15] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[15]),
        .Q(Q[15]));
  FDCE #(
    .INIT(1'b0)) 
    \WB_ALU_Result_reg[16] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[16]),
        .Q(Q[16]));
  FDCE #(
    .INIT(1'b0)) 
    \WB_ALU_Result_reg[17] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[17]),
        .Q(Q[17]));
  FDCE #(
    .INIT(1'b0)) 
    \WB_ALU_Result_reg[18] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[18]),
        .Q(Q[18]));
  FDCE #(
    .INIT(1'b0)) 
    \WB_ALU_Result_reg[19] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[19]),
        .Q(Q[19]));
  FDCE #(
    .INIT(1'b0)) 
    \WB_ALU_Result_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[1]),
        .Q(Q[1]));
  FDCE #(
    .INIT(1'b0)) 
    \WB_ALU_Result_reg[20] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[20]),
        .Q(Q[20]));
  FDCE #(
    .INIT(1'b0)) 
    \WB_ALU_Result_reg[21] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[21]),
        .Q(Q[21]));
  FDCE #(
    .INIT(1'b0)) 
    \WB_ALU_Result_reg[22] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[22]),
        .Q(Q[22]));
  FDCE #(
    .INIT(1'b0)) 
    \WB_ALU_Result_reg[23] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[23]),
        .Q(Q[23]));
  FDCE #(
    .INIT(1'b0)) 
    \WB_ALU_Result_reg[24] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[24]),
        .Q(Q[24]));
  FDCE #(
    .INIT(1'b0)) 
    \WB_ALU_Result_reg[25] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[25]),
        .Q(Q[25]));
  FDCE #(
    .INIT(1'b0)) 
    \WB_ALU_Result_reg[26] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[26]),
        .Q(Q[26]));
  FDCE #(
    .INIT(1'b0)) 
    \WB_ALU_Result_reg[27] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[27]),
        .Q(Q[27]));
  FDCE #(
    .INIT(1'b0)) 
    \WB_ALU_Result_reg[28] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[28]),
        .Q(Q[28]));
  FDCE #(
    .INIT(1'b0)) 
    \WB_ALU_Result_reg[29] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[29]),
        .Q(Q[29]));
  FDCE #(
    .INIT(1'b0)) 
    \WB_ALU_Result_reg[2] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[2]),
        .Q(Q[2]));
  FDCE #(
    .INIT(1'b0)) 
    \WB_ALU_Result_reg[30] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[30]),
        .Q(Q[30]));
  FDCE #(
    .INIT(1'b0)) 
    \WB_ALU_Result_reg[31] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[31]),
        .Q(Q[31]));
  FDCE #(
    .INIT(1'b0)) 
    \WB_ALU_Result_reg[3] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[3]),
        .Q(Q[3]));
  FDCE #(
    .INIT(1'b0)) 
    \WB_ALU_Result_reg[4] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[4]),
        .Q(Q[4]));
  FDCE #(
    .INIT(1'b0)) 
    \WB_ALU_Result_reg[5] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[5]),
        .Q(Q[5]));
  FDCE #(
    .INIT(1'b0)) 
    \WB_ALU_Result_reg[6] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[6]),
        .Q(Q[6]));
  FDCE #(
    .INIT(1'b0)) 
    \WB_ALU_Result_reg[7] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[7]),
        .Q(Q[7]));
  FDCE #(
    .INIT(1'b0)) 
    \WB_ALU_Result_reg[8] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[8]),
        .Q(Q[8]));
  FDCE #(
    .INIT(1'b0)) 
    \WB_ALU_Result_reg[9] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(D[9]),
        .Q(Q[9]));
endmodule

module alu
   (data0,
    EX_ReadData1,
    DOADO,
    \MEM_ALU_Result_reg[3] ,
    \MEM_ALU_Result_reg[15] ,
    DOBDO,
    \MEM_ALU_Result_reg[31] );
  output [31:0]data0;
  input [30:0]EX_ReadData1;
  input [15:0]DOADO;
  input \MEM_ALU_Result_reg[3] ;
  input [15:0]\MEM_ALU_Result_reg[15] ;
  input [15:0]DOBDO;
  input [15:0]\MEM_ALU_Result_reg[31] ;

  wire [15:0]DOADO;
  wire [15:0]DOBDO;
  wire [30:0]EX_ReadData1;
  wire [15:0]\MEM_ALU_Result_reg[15] ;
  wire [15:0]\MEM_ALU_Result_reg[31] ;
  wire \MEM_ALU_Result_reg[3] ;
  wire \alu_result_out_OBUF[11]_inst_i_1_n_0 ;
  wire \alu_result_out_OBUF[11]_inst_i_6_n_0 ;
  wire \alu_result_out_OBUF[11]_inst_i_7_n_0 ;
  wire \alu_result_out_OBUF[11]_inst_i_8_n_0 ;
  wire \alu_result_out_OBUF[11]_inst_i_9_n_0 ;
  wire \alu_result_out_OBUF[15]_inst_i_1_n_0 ;
  wire \alu_result_out_OBUF[15]_inst_i_6_n_0 ;
  wire \alu_result_out_OBUF[15]_inst_i_7_n_0 ;
  wire \alu_result_out_OBUF[15]_inst_i_8_n_0 ;
  wire \alu_result_out_OBUF[15]_inst_i_9_n_0 ;
  wire \alu_result_out_OBUF[19]_inst_i_1_n_0 ;
  wire \alu_result_out_OBUF[19]_inst_i_6_n_0 ;
  wire \alu_result_out_OBUF[19]_inst_i_7_n_0 ;
  wire \alu_result_out_OBUF[19]_inst_i_8_n_0 ;
  wire \alu_result_out_OBUF[19]_inst_i_9_n_0 ;
  wire \alu_result_out_OBUF[23]_inst_i_1_n_0 ;
  wire \alu_result_out_OBUF[23]_inst_i_6_n_0 ;
  wire \alu_result_out_OBUF[23]_inst_i_7_n_0 ;
  wire \alu_result_out_OBUF[23]_inst_i_8_n_0 ;
  wire \alu_result_out_OBUF[23]_inst_i_9_n_0 ;
  wire \alu_result_out_OBUF[27]_inst_i_1_n_0 ;
  wire \alu_result_out_OBUF[27]_inst_i_6_n_0 ;
  wire \alu_result_out_OBUF[27]_inst_i_7_n_0 ;
  wire \alu_result_out_OBUF[27]_inst_i_8_n_0 ;
  wire \alu_result_out_OBUF[27]_inst_i_9_n_0 ;
  wire \alu_result_out_OBUF[31]_inst_i_5_n_0 ;
  wire \alu_result_out_OBUF[31]_inst_i_6_n_0 ;
  wire \alu_result_out_OBUF[31]_inst_i_7_n_0 ;
  wire \alu_result_out_OBUF[31]_inst_i_8_n_0 ;
  wire \alu_result_out_OBUF[3]_inst_i_1_n_0 ;
  wire \alu_result_out_OBUF[3]_inst_i_6_n_0 ;
  wire \alu_result_out_OBUF[3]_inst_i_7_n_0 ;
  wire \alu_result_out_OBUF[3]_inst_i_8_n_0 ;
  wire \alu_result_out_OBUF[3]_inst_i_9_n_0 ;
  wire \alu_result_out_OBUF[7]_inst_i_1_n_0 ;
  wire \alu_result_out_OBUF[7]_inst_i_6_n_0 ;
  wire \alu_result_out_OBUF[7]_inst_i_7_n_0 ;
  wire \alu_result_out_OBUF[7]_inst_i_8_n_0 ;
  wire \alu_result_out_OBUF[7]_inst_i_9_n_0 ;
  wire [31:0]data0;
  wire [2:0]\NLW_alu_result_out_OBUF[11]_inst_i_1_CO_UNCONNECTED ;
  wire [2:0]\NLW_alu_result_out_OBUF[15]_inst_i_1_CO_UNCONNECTED ;
  wire [2:0]\NLW_alu_result_out_OBUF[19]_inst_i_1_CO_UNCONNECTED ;
  wire [2:0]\NLW_alu_result_out_OBUF[23]_inst_i_1_CO_UNCONNECTED ;
  wire [2:0]\NLW_alu_result_out_OBUF[27]_inst_i_1_CO_UNCONNECTED ;
  wire [3:0]\NLW_alu_result_out_OBUF[31]_inst_i_1_CO_UNCONNECTED ;
  wire [2:0]\NLW_alu_result_out_OBUF[3]_inst_i_1_CO_UNCONNECTED ;
  wire [2:0]\NLW_alu_result_out_OBUF[7]_inst_i_1_CO_UNCONNECTED ;

  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \alu_result_out_OBUF[11]_inst_i_1 
       (.CI(\alu_result_out_OBUF[7]_inst_i_1_n_0 ),
        .CO({\alu_result_out_OBUF[11]_inst_i_1_n_0 ,\NLW_alu_result_out_OBUF[11]_inst_i_1_CO_UNCONNECTED [2:0]}),
        .CYINIT(1'b0),
        .DI(EX_ReadData1[11:8]),
        .O(data0[11:8]),
        .S({\alu_result_out_OBUF[11]_inst_i_6_n_0 ,\alu_result_out_OBUF[11]_inst_i_7_n_0 ,\alu_result_out_OBUF[11]_inst_i_8_n_0 ,\alu_result_out_OBUF[11]_inst_i_9_n_0 }));
  LUT3 #(
    .INIT(8'h48)) 
    \alu_result_out_OBUF[11]_inst_i_6 
       (.I0(DOADO[11]),
        .I1(\MEM_ALU_Result_reg[3] ),
        .I2(\MEM_ALU_Result_reg[15] [11]),
        .O(\alu_result_out_OBUF[11]_inst_i_6_n_0 ));
  LUT3 #(
    .INIT(8'h48)) 
    \alu_result_out_OBUF[11]_inst_i_7 
       (.I0(DOADO[10]),
        .I1(\MEM_ALU_Result_reg[3] ),
        .I2(\MEM_ALU_Result_reg[15] [10]),
        .O(\alu_result_out_OBUF[11]_inst_i_7_n_0 ));
  LUT3 #(
    .INIT(8'h48)) 
    \alu_result_out_OBUF[11]_inst_i_8 
       (.I0(DOADO[9]),
        .I1(\MEM_ALU_Result_reg[3] ),
        .I2(\MEM_ALU_Result_reg[15] [9]),
        .O(\alu_result_out_OBUF[11]_inst_i_8_n_0 ));
  LUT3 #(
    .INIT(8'h48)) 
    \alu_result_out_OBUF[11]_inst_i_9 
       (.I0(DOADO[8]),
        .I1(\MEM_ALU_Result_reg[3] ),
        .I2(\MEM_ALU_Result_reg[15] [8]),
        .O(\alu_result_out_OBUF[11]_inst_i_9_n_0 ));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \alu_result_out_OBUF[15]_inst_i_1 
       (.CI(\alu_result_out_OBUF[11]_inst_i_1_n_0 ),
        .CO({\alu_result_out_OBUF[15]_inst_i_1_n_0 ,\NLW_alu_result_out_OBUF[15]_inst_i_1_CO_UNCONNECTED [2:0]}),
        .CYINIT(1'b0),
        .DI(EX_ReadData1[15:12]),
        .O(data0[15:12]),
        .S({\alu_result_out_OBUF[15]_inst_i_6_n_0 ,\alu_result_out_OBUF[15]_inst_i_7_n_0 ,\alu_result_out_OBUF[15]_inst_i_8_n_0 ,\alu_result_out_OBUF[15]_inst_i_9_n_0 }));
  LUT3 #(
    .INIT(8'h48)) 
    \alu_result_out_OBUF[15]_inst_i_6 
       (.I0(DOADO[15]),
        .I1(\MEM_ALU_Result_reg[3] ),
        .I2(\MEM_ALU_Result_reg[15] [15]),
        .O(\alu_result_out_OBUF[15]_inst_i_6_n_0 ));
  LUT3 #(
    .INIT(8'h48)) 
    \alu_result_out_OBUF[15]_inst_i_7 
       (.I0(DOADO[14]),
        .I1(\MEM_ALU_Result_reg[3] ),
        .I2(\MEM_ALU_Result_reg[15] [14]),
        .O(\alu_result_out_OBUF[15]_inst_i_7_n_0 ));
  LUT3 #(
    .INIT(8'h48)) 
    \alu_result_out_OBUF[15]_inst_i_8 
       (.I0(DOADO[13]),
        .I1(\MEM_ALU_Result_reg[3] ),
        .I2(\MEM_ALU_Result_reg[15] [13]),
        .O(\alu_result_out_OBUF[15]_inst_i_8_n_0 ));
  LUT3 #(
    .INIT(8'h48)) 
    \alu_result_out_OBUF[15]_inst_i_9 
       (.I0(DOADO[12]),
        .I1(\MEM_ALU_Result_reg[3] ),
        .I2(\MEM_ALU_Result_reg[15] [12]),
        .O(\alu_result_out_OBUF[15]_inst_i_9_n_0 ));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \alu_result_out_OBUF[19]_inst_i_1 
       (.CI(\alu_result_out_OBUF[15]_inst_i_1_n_0 ),
        .CO({\alu_result_out_OBUF[19]_inst_i_1_n_0 ,\NLW_alu_result_out_OBUF[19]_inst_i_1_CO_UNCONNECTED [2:0]}),
        .CYINIT(1'b0),
        .DI(EX_ReadData1[19:16]),
        .O(data0[19:16]),
        .S({\alu_result_out_OBUF[19]_inst_i_6_n_0 ,\alu_result_out_OBUF[19]_inst_i_7_n_0 ,\alu_result_out_OBUF[19]_inst_i_8_n_0 ,\alu_result_out_OBUF[19]_inst_i_9_n_0 }));
  LUT3 #(
    .INIT(8'h48)) 
    \alu_result_out_OBUF[19]_inst_i_6 
       (.I0(DOBDO[3]),
        .I1(\MEM_ALU_Result_reg[3] ),
        .I2(\MEM_ALU_Result_reg[31] [3]),
        .O(\alu_result_out_OBUF[19]_inst_i_6_n_0 ));
  LUT3 #(
    .INIT(8'h48)) 
    \alu_result_out_OBUF[19]_inst_i_7 
       (.I0(DOBDO[2]),
        .I1(\MEM_ALU_Result_reg[3] ),
        .I2(\MEM_ALU_Result_reg[31] [2]),
        .O(\alu_result_out_OBUF[19]_inst_i_7_n_0 ));
  LUT3 #(
    .INIT(8'h48)) 
    \alu_result_out_OBUF[19]_inst_i_8 
       (.I0(DOBDO[1]),
        .I1(\MEM_ALU_Result_reg[3] ),
        .I2(\MEM_ALU_Result_reg[31] [1]),
        .O(\alu_result_out_OBUF[19]_inst_i_8_n_0 ));
  LUT3 #(
    .INIT(8'h48)) 
    \alu_result_out_OBUF[19]_inst_i_9 
       (.I0(DOBDO[0]),
        .I1(\MEM_ALU_Result_reg[3] ),
        .I2(\MEM_ALU_Result_reg[31] [0]),
        .O(\alu_result_out_OBUF[19]_inst_i_9_n_0 ));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \alu_result_out_OBUF[23]_inst_i_1 
       (.CI(\alu_result_out_OBUF[19]_inst_i_1_n_0 ),
        .CO({\alu_result_out_OBUF[23]_inst_i_1_n_0 ,\NLW_alu_result_out_OBUF[23]_inst_i_1_CO_UNCONNECTED [2:0]}),
        .CYINIT(1'b0),
        .DI(EX_ReadData1[23:20]),
        .O(data0[23:20]),
        .S({\alu_result_out_OBUF[23]_inst_i_6_n_0 ,\alu_result_out_OBUF[23]_inst_i_7_n_0 ,\alu_result_out_OBUF[23]_inst_i_8_n_0 ,\alu_result_out_OBUF[23]_inst_i_9_n_0 }));
  LUT3 #(
    .INIT(8'h48)) 
    \alu_result_out_OBUF[23]_inst_i_6 
       (.I0(DOBDO[7]),
        .I1(\MEM_ALU_Result_reg[3] ),
        .I2(\MEM_ALU_Result_reg[31] [7]),
        .O(\alu_result_out_OBUF[23]_inst_i_6_n_0 ));
  LUT3 #(
    .INIT(8'h48)) 
    \alu_result_out_OBUF[23]_inst_i_7 
       (.I0(DOBDO[6]),
        .I1(\MEM_ALU_Result_reg[3] ),
        .I2(\MEM_ALU_Result_reg[31] [6]),
        .O(\alu_result_out_OBUF[23]_inst_i_7_n_0 ));
  LUT3 #(
    .INIT(8'h48)) 
    \alu_result_out_OBUF[23]_inst_i_8 
       (.I0(DOBDO[5]),
        .I1(\MEM_ALU_Result_reg[3] ),
        .I2(\MEM_ALU_Result_reg[31] [5]),
        .O(\alu_result_out_OBUF[23]_inst_i_8_n_0 ));
  LUT3 #(
    .INIT(8'h48)) 
    \alu_result_out_OBUF[23]_inst_i_9 
       (.I0(DOBDO[4]),
        .I1(\MEM_ALU_Result_reg[3] ),
        .I2(\MEM_ALU_Result_reg[31] [4]),
        .O(\alu_result_out_OBUF[23]_inst_i_9_n_0 ));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \alu_result_out_OBUF[27]_inst_i_1 
       (.CI(\alu_result_out_OBUF[23]_inst_i_1_n_0 ),
        .CO({\alu_result_out_OBUF[27]_inst_i_1_n_0 ,\NLW_alu_result_out_OBUF[27]_inst_i_1_CO_UNCONNECTED [2:0]}),
        .CYINIT(1'b0),
        .DI(EX_ReadData1[27:24]),
        .O(data0[27:24]),
        .S({\alu_result_out_OBUF[27]_inst_i_6_n_0 ,\alu_result_out_OBUF[27]_inst_i_7_n_0 ,\alu_result_out_OBUF[27]_inst_i_8_n_0 ,\alu_result_out_OBUF[27]_inst_i_9_n_0 }));
  LUT3 #(
    .INIT(8'h48)) 
    \alu_result_out_OBUF[27]_inst_i_6 
       (.I0(DOBDO[11]),
        .I1(\MEM_ALU_Result_reg[3] ),
        .I2(\MEM_ALU_Result_reg[31] [11]),
        .O(\alu_result_out_OBUF[27]_inst_i_6_n_0 ));
  LUT3 #(
    .INIT(8'h48)) 
    \alu_result_out_OBUF[27]_inst_i_7 
       (.I0(DOBDO[10]),
        .I1(\MEM_ALU_Result_reg[3] ),
        .I2(\MEM_ALU_Result_reg[31] [10]),
        .O(\alu_result_out_OBUF[27]_inst_i_7_n_0 ));
  LUT3 #(
    .INIT(8'h48)) 
    \alu_result_out_OBUF[27]_inst_i_8 
       (.I0(DOBDO[9]),
        .I1(\MEM_ALU_Result_reg[3] ),
        .I2(\MEM_ALU_Result_reg[31] [9]),
        .O(\alu_result_out_OBUF[27]_inst_i_8_n_0 ));
  LUT3 #(
    .INIT(8'h48)) 
    \alu_result_out_OBUF[27]_inst_i_9 
       (.I0(DOBDO[8]),
        .I1(\MEM_ALU_Result_reg[3] ),
        .I2(\MEM_ALU_Result_reg[31] [8]),
        .O(\alu_result_out_OBUF[27]_inst_i_9_n_0 ));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \alu_result_out_OBUF[31]_inst_i_1 
       (.CI(\alu_result_out_OBUF[27]_inst_i_1_n_0 ),
        .CO(\NLW_alu_result_out_OBUF[31]_inst_i_1_CO_UNCONNECTED [3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,EX_ReadData1[30:28]}),
        .O(data0[31:28]),
        .S({\alu_result_out_OBUF[31]_inst_i_5_n_0 ,\alu_result_out_OBUF[31]_inst_i_6_n_0 ,\alu_result_out_OBUF[31]_inst_i_7_n_0 ,\alu_result_out_OBUF[31]_inst_i_8_n_0 }));
  LUT3 #(
    .INIT(8'h48)) 
    \alu_result_out_OBUF[31]_inst_i_5 
       (.I0(DOBDO[15]),
        .I1(\MEM_ALU_Result_reg[3] ),
        .I2(\MEM_ALU_Result_reg[31] [15]),
        .O(\alu_result_out_OBUF[31]_inst_i_5_n_0 ));
  LUT3 #(
    .INIT(8'h48)) 
    \alu_result_out_OBUF[31]_inst_i_6 
       (.I0(DOBDO[14]),
        .I1(\MEM_ALU_Result_reg[3] ),
        .I2(\MEM_ALU_Result_reg[31] [14]),
        .O(\alu_result_out_OBUF[31]_inst_i_6_n_0 ));
  LUT3 #(
    .INIT(8'h48)) 
    \alu_result_out_OBUF[31]_inst_i_7 
       (.I0(DOBDO[13]),
        .I1(\MEM_ALU_Result_reg[3] ),
        .I2(\MEM_ALU_Result_reg[31] [13]),
        .O(\alu_result_out_OBUF[31]_inst_i_7_n_0 ));
  LUT3 #(
    .INIT(8'h48)) 
    \alu_result_out_OBUF[31]_inst_i_8 
       (.I0(DOBDO[12]),
        .I1(\MEM_ALU_Result_reg[3] ),
        .I2(\MEM_ALU_Result_reg[31] [12]),
        .O(\alu_result_out_OBUF[31]_inst_i_8_n_0 ));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \alu_result_out_OBUF[3]_inst_i_1 
       (.CI(1'b0),
        .CO({\alu_result_out_OBUF[3]_inst_i_1_n_0 ,\NLW_alu_result_out_OBUF[3]_inst_i_1_CO_UNCONNECTED [2:0]}),
        .CYINIT(1'b0),
        .DI(EX_ReadData1[3:0]),
        .O(data0[3:0]),
        .S({\alu_result_out_OBUF[3]_inst_i_6_n_0 ,\alu_result_out_OBUF[3]_inst_i_7_n_0 ,\alu_result_out_OBUF[3]_inst_i_8_n_0 ,\alu_result_out_OBUF[3]_inst_i_9_n_0 }));
  LUT3 #(
    .INIT(8'h48)) 
    \alu_result_out_OBUF[3]_inst_i_6 
       (.I0(DOADO[3]),
        .I1(\MEM_ALU_Result_reg[3] ),
        .I2(\MEM_ALU_Result_reg[15] [3]),
        .O(\alu_result_out_OBUF[3]_inst_i_6_n_0 ));
  LUT3 #(
    .INIT(8'h48)) 
    \alu_result_out_OBUF[3]_inst_i_7 
       (.I0(DOADO[2]),
        .I1(\MEM_ALU_Result_reg[3] ),
        .I2(\MEM_ALU_Result_reg[15] [2]),
        .O(\alu_result_out_OBUF[3]_inst_i_7_n_0 ));
  LUT3 #(
    .INIT(8'h48)) 
    \alu_result_out_OBUF[3]_inst_i_8 
       (.I0(DOADO[1]),
        .I1(\MEM_ALU_Result_reg[3] ),
        .I2(\MEM_ALU_Result_reg[15] [1]),
        .O(\alu_result_out_OBUF[3]_inst_i_8_n_0 ));
  LUT3 #(
    .INIT(8'h48)) 
    \alu_result_out_OBUF[3]_inst_i_9 
       (.I0(DOADO[0]),
        .I1(\MEM_ALU_Result_reg[3] ),
        .I2(\MEM_ALU_Result_reg[15] [0]),
        .O(\alu_result_out_OBUF[3]_inst_i_9_n_0 ));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \alu_result_out_OBUF[7]_inst_i_1 
       (.CI(\alu_result_out_OBUF[3]_inst_i_1_n_0 ),
        .CO({\alu_result_out_OBUF[7]_inst_i_1_n_0 ,\NLW_alu_result_out_OBUF[7]_inst_i_1_CO_UNCONNECTED [2:0]}),
        .CYINIT(1'b0),
        .DI(EX_ReadData1[7:4]),
        .O(data0[7:4]),
        .S({\alu_result_out_OBUF[7]_inst_i_6_n_0 ,\alu_result_out_OBUF[7]_inst_i_7_n_0 ,\alu_result_out_OBUF[7]_inst_i_8_n_0 ,\alu_result_out_OBUF[7]_inst_i_9_n_0 }));
  LUT3 #(
    .INIT(8'h48)) 
    \alu_result_out_OBUF[7]_inst_i_6 
       (.I0(DOADO[7]),
        .I1(\MEM_ALU_Result_reg[3] ),
        .I2(\MEM_ALU_Result_reg[15] [7]),
        .O(\alu_result_out_OBUF[7]_inst_i_6_n_0 ));
  LUT3 #(
    .INIT(8'h48)) 
    \alu_result_out_OBUF[7]_inst_i_7 
       (.I0(DOADO[6]),
        .I1(\MEM_ALU_Result_reg[3] ),
        .I2(\MEM_ALU_Result_reg[15] [6]),
        .O(\alu_result_out_OBUF[7]_inst_i_7_n_0 ));
  LUT3 #(
    .INIT(8'h48)) 
    \alu_result_out_OBUF[7]_inst_i_8 
       (.I0(DOADO[5]),
        .I1(\MEM_ALU_Result_reg[3] ),
        .I2(\MEM_ALU_Result_reg[15] [5]),
        .O(\alu_result_out_OBUF[7]_inst_i_8_n_0 ));
  LUT3 #(
    .INIT(8'h48)) 
    \alu_result_out_OBUF[7]_inst_i_9 
       (.I0(DOADO[4]),
        .I1(\MEM_ALU_Result_reg[3] ),
        .I2(\MEM_ALU_Result_reg[15] [4]),
        .O(\alu_result_out_OBUF[7]_inst_i_9_n_0 ));
endmodule

module program_counter
   (out,
    clk_IBUF_BUFG,
    reset_IBUF);
  output [29:0]out;
  input clk_IBUF_BUFG;
  input reset_IBUF;

  wire clk_IBUF_BUFG;
  wire [29:0]out;
  wire \pc[2]_i_2_n_0 ;
  wire \pc_reg[10]_i_1_n_0 ;
  wire \pc_reg[10]_i_1_n_4 ;
  wire \pc_reg[10]_i_1_n_5 ;
  wire \pc_reg[10]_i_1_n_6 ;
  wire \pc_reg[10]_i_1_n_7 ;
  wire \pc_reg[14]_i_1_n_0 ;
  wire \pc_reg[14]_i_1_n_4 ;
  wire \pc_reg[14]_i_1_n_5 ;
  wire \pc_reg[14]_i_1_n_6 ;
  wire \pc_reg[14]_i_1_n_7 ;
  wire \pc_reg[18]_i_1_n_0 ;
  wire \pc_reg[18]_i_1_n_4 ;
  wire \pc_reg[18]_i_1_n_5 ;
  wire \pc_reg[18]_i_1_n_6 ;
  wire \pc_reg[18]_i_1_n_7 ;
  wire \pc_reg[22]_i_1_n_0 ;
  wire \pc_reg[22]_i_1_n_4 ;
  wire \pc_reg[22]_i_1_n_5 ;
  wire \pc_reg[22]_i_1_n_6 ;
  wire \pc_reg[22]_i_1_n_7 ;
  wire \pc_reg[26]_i_1_n_0 ;
  wire \pc_reg[26]_i_1_n_4 ;
  wire \pc_reg[26]_i_1_n_5 ;
  wire \pc_reg[26]_i_1_n_6 ;
  wire \pc_reg[26]_i_1_n_7 ;
  wire \pc_reg[2]_i_1_n_0 ;
  wire \pc_reg[2]_i_1_n_4 ;
  wire \pc_reg[2]_i_1_n_5 ;
  wire \pc_reg[2]_i_1_n_6 ;
  wire \pc_reg[2]_i_1_n_7 ;
  wire \pc_reg[30]_i_1_n_6 ;
  wire \pc_reg[30]_i_1_n_7 ;
  wire \pc_reg[6]_i_1_n_0 ;
  wire \pc_reg[6]_i_1_n_4 ;
  wire \pc_reg[6]_i_1_n_5 ;
  wire \pc_reg[6]_i_1_n_6 ;
  wire \pc_reg[6]_i_1_n_7 ;
  wire reset_IBUF;
  wire [2:0]\NLW_pc_reg[10]_i_1_CO_UNCONNECTED ;
  wire [2:0]\NLW_pc_reg[14]_i_1_CO_UNCONNECTED ;
  wire [2:0]\NLW_pc_reg[18]_i_1_CO_UNCONNECTED ;
  wire [2:0]\NLW_pc_reg[22]_i_1_CO_UNCONNECTED ;
  wire [2:0]\NLW_pc_reg[26]_i_1_CO_UNCONNECTED ;
  wire [2:0]\NLW_pc_reg[2]_i_1_CO_UNCONNECTED ;
  wire [3:0]\NLW_pc_reg[30]_i_1_CO_UNCONNECTED ;
  wire [3:2]\NLW_pc_reg[30]_i_1_O_UNCONNECTED ;
  wire [2:0]\NLW_pc_reg[6]_i_1_CO_UNCONNECTED ;

  LUT1 #(
    .INIT(2'h1)) 
    \pc[2]_i_2 
       (.I0(out[0]),
        .O(\pc[2]_i_2_n_0 ));
  FDCE #(
    .INIT(1'b0)) 
    \pc_reg[10] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(\pc_reg[10]_i_1_n_7 ),
        .Q(out[8]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \pc_reg[10]_i_1 
       (.CI(\pc_reg[6]_i_1_n_0 ),
        .CO({\pc_reg[10]_i_1_n_0 ,\NLW_pc_reg[10]_i_1_CO_UNCONNECTED [2:0]}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\pc_reg[10]_i_1_n_4 ,\pc_reg[10]_i_1_n_5 ,\pc_reg[10]_i_1_n_6 ,\pc_reg[10]_i_1_n_7 }),
        .S(out[11:8]));
  FDCE #(
    .INIT(1'b0)) 
    \pc_reg[11] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(\pc_reg[10]_i_1_n_6 ),
        .Q(out[9]));
  FDCE #(
    .INIT(1'b0)) 
    \pc_reg[12] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(\pc_reg[10]_i_1_n_5 ),
        .Q(out[10]));
  FDCE #(
    .INIT(1'b0)) 
    \pc_reg[13] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(\pc_reg[10]_i_1_n_4 ),
        .Q(out[11]));
  FDCE #(
    .INIT(1'b0)) 
    \pc_reg[14] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(\pc_reg[14]_i_1_n_7 ),
        .Q(out[12]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \pc_reg[14]_i_1 
       (.CI(\pc_reg[10]_i_1_n_0 ),
        .CO({\pc_reg[14]_i_1_n_0 ,\NLW_pc_reg[14]_i_1_CO_UNCONNECTED [2:0]}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\pc_reg[14]_i_1_n_4 ,\pc_reg[14]_i_1_n_5 ,\pc_reg[14]_i_1_n_6 ,\pc_reg[14]_i_1_n_7 }),
        .S(out[15:12]));
  FDCE #(
    .INIT(1'b0)) 
    \pc_reg[15] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(\pc_reg[14]_i_1_n_6 ),
        .Q(out[13]));
  FDCE #(
    .INIT(1'b0)) 
    \pc_reg[16] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(\pc_reg[14]_i_1_n_5 ),
        .Q(out[14]));
  FDCE #(
    .INIT(1'b0)) 
    \pc_reg[17] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(\pc_reg[14]_i_1_n_4 ),
        .Q(out[15]));
  FDCE #(
    .INIT(1'b0)) 
    \pc_reg[18] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(\pc_reg[18]_i_1_n_7 ),
        .Q(out[16]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \pc_reg[18]_i_1 
       (.CI(\pc_reg[14]_i_1_n_0 ),
        .CO({\pc_reg[18]_i_1_n_0 ,\NLW_pc_reg[18]_i_1_CO_UNCONNECTED [2:0]}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\pc_reg[18]_i_1_n_4 ,\pc_reg[18]_i_1_n_5 ,\pc_reg[18]_i_1_n_6 ,\pc_reg[18]_i_1_n_7 }),
        .S(out[19:16]));
  FDCE #(
    .INIT(1'b0)) 
    \pc_reg[19] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(\pc_reg[18]_i_1_n_6 ),
        .Q(out[17]));
  FDCE #(
    .INIT(1'b0)) 
    \pc_reg[20] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(\pc_reg[18]_i_1_n_5 ),
        .Q(out[18]));
  FDCE #(
    .INIT(1'b0)) 
    \pc_reg[21] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(\pc_reg[18]_i_1_n_4 ),
        .Q(out[19]));
  FDCE #(
    .INIT(1'b0)) 
    \pc_reg[22] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(\pc_reg[22]_i_1_n_7 ),
        .Q(out[20]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \pc_reg[22]_i_1 
       (.CI(\pc_reg[18]_i_1_n_0 ),
        .CO({\pc_reg[22]_i_1_n_0 ,\NLW_pc_reg[22]_i_1_CO_UNCONNECTED [2:0]}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\pc_reg[22]_i_1_n_4 ,\pc_reg[22]_i_1_n_5 ,\pc_reg[22]_i_1_n_6 ,\pc_reg[22]_i_1_n_7 }),
        .S(out[23:20]));
  FDCE #(
    .INIT(1'b0)) 
    \pc_reg[23] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(\pc_reg[22]_i_1_n_6 ),
        .Q(out[21]));
  FDCE #(
    .INIT(1'b0)) 
    \pc_reg[24] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(\pc_reg[22]_i_1_n_5 ),
        .Q(out[22]));
  FDCE #(
    .INIT(1'b0)) 
    \pc_reg[25] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(\pc_reg[22]_i_1_n_4 ),
        .Q(out[23]));
  FDCE #(
    .INIT(1'b0)) 
    \pc_reg[26] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(\pc_reg[26]_i_1_n_7 ),
        .Q(out[24]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \pc_reg[26]_i_1 
       (.CI(\pc_reg[22]_i_1_n_0 ),
        .CO({\pc_reg[26]_i_1_n_0 ,\NLW_pc_reg[26]_i_1_CO_UNCONNECTED [2:0]}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\pc_reg[26]_i_1_n_4 ,\pc_reg[26]_i_1_n_5 ,\pc_reg[26]_i_1_n_6 ,\pc_reg[26]_i_1_n_7 }),
        .S(out[27:24]));
  FDCE #(
    .INIT(1'b0)) 
    \pc_reg[27] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(\pc_reg[26]_i_1_n_6 ),
        .Q(out[25]));
  FDCE #(
    .INIT(1'b0)) 
    \pc_reg[28] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(\pc_reg[26]_i_1_n_5 ),
        .Q(out[26]));
  FDCE #(
    .INIT(1'b0)) 
    \pc_reg[29] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(\pc_reg[26]_i_1_n_4 ),
        .Q(out[27]));
  FDCE #(
    .INIT(1'b0)) 
    \pc_reg[2] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(\pc_reg[2]_i_1_n_7 ),
        .Q(out[0]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \pc_reg[2]_i_1 
       (.CI(1'b0),
        .CO({\pc_reg[2]_i_1_n_0 ,\NLW_pc_reg[2]_i_1_CO_UNCONNECTED [2:0]}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b1}),
        .O({\pc_reg[2]_i_1_n_4 ,\pc_reg[2]_i_1_n_5 ,\pc_reg[2]_i_1_n_6 ,\pc_reg[2]_i_1_n_7 }),
        .S({out[3:1],\pc[2]_i_2_n_0 }));
  FDCE #(
    .INIT(1'b0)) 
    \pc_reg[30] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(\pc_reg[30]_i_1_n_7 ),
        .Q(out[28]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \pc_reg[30]_i_1 
       (.CI(\pc_reg[26]_i_1_n_0 ),
        .CO(\NLW_pc_reg[30]_i_1_CO_UNCONNECTED [3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_pc_reg[30]_i_1_O_UNCONNECTED [3:2],\pc_reg[30]_i_1_n_6 ,\pc_reg[30]_i_1_n_7 }),
        .S({1'b0,1'b0,out[29:28]}));
  FDCE #(
    .INIT(1'b0)) 
    \pc_reg[31] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(\pc_reg[30]_i_1_n_6 ),
        .Q(out[29]));
  FDCE #(
    .INIT(1'b0)) 
    \pc_reg[3] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(\pc_reg[2]_i_1_n_6 ),
        .Q(out[1]));
  FDCE #(
    .INIT(1'b0)) 
    \pc_reg[4] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(\pc_reg[2]_i_1_n_5 ),
        .Q(out[2]));
  FDCE #(
    .INIT(1'b0)) 
    \pc_reg[5] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(\pc_reg[2]_i_1_n_4 ),
        .Q(out[3]));
  FDCE #(
    .INIT(1'b0)) 
    \pc_reg[6] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(\pc_reg[6]_i_1_n_7 ),
        .Q(out[4]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \pc_reg[6]_i_1 
       (.CI(\pc_reg[2]_i_1_n_0 ),
        .CO({\pc_reg[6]_i_1_n_0 ,\NLW_pc_reg[6]_i_1_CO_UNCONNECTED [2:0]}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\pc_reg[6]_i_1_n_4 ,\pc_reg[6]_i_1_n_5 ,\pc_reg[6]_i_1_n_6 ,\pc_reg[6]_i_1_n_7 }),
        .S(out[7:4]));
  FDCE #(
    .INIT(1'b0)) 
    \pc_reg[7] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(\pc_reg[6]_i_1_n_6 ),
        .Q(out[5]));
  FDCE #(
    .INIT(1'b0)) 
    \pc_reg[8] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(\pc_reg[6]_i_1_n_5 ),
        .Q(out[6]));
  FDCE #(
    .INIT(1'b0)) 
    \pc_reg[9] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(\pc_reg[6]_i_1_n_4 ),
        .Q(out[7]));
endmodule

module register_file
   (DOADO,
    DOBDO,
    registers_reg_2_0,
    registers_reg_2_1,
    EX_ReadData1,
    registers_reg_async_reset_b_0,
    clk_IBUF_BUFG,
    reset_IBUF,
    WB_ALU_Result,
    RegWrite_out);
  output [15:0]DOADO;
  output [15:0]DOBDO;
  output [15:0]registers_reg_2_0;
  output [15:0]registers_reg_2_1;
  output [30:0]EX_ReadData1;
  output registers_reg_async_reset_b_0;
  input clk_IBUF_BUFG;
  input reset_IBUF;
  input [31:0]WB_ALU_Result;
  input RegWrite_out;

  wire [15:0]DOADO;
  wire [15:0]DOBDO;
  wire [30:0]EX_ReadData1;
  wire RegWrite_out;
  wire [31:0]WB_ALU_Result;
  wire clk_IBUF_BUFG;
  wire [15:0]registers_reg_2_0;
  wire [15:0]registers_reg_2_1;
  wire registers_reg_async_reset_b_0;
  wire reset_IBUF;
  wire [1:0]NLW_registers_reg_1_DOPADOP_UNCONNECTED;
  wire [1:0]NLW_registers_reg_1_DOPBDOP_UNCONNECTED;
  wire [1:0]NLW_registers_reg_2_DOPADOP_UNCONNECTED;
  wire [1:0]NLW_registers_reg_2_DOPBDOP_UNCONNECTED;

  LUT2 #(
    .INIT(4'h8)) 
    \alu_result_out_OBUF[11]_inst_i_2 
       (.I0(DOADO[11]),
        .I1(registers_reg_async_reset_b_0),
        .O(EX_ReadData1[11]));
  LUT2 #(
    .INIT(4'h8)) 
    \alu_result_out_OBUF[11]_inst_i_3 
       (.I0(DOADO[10]),
        .I1(registers_reg_async_reset_b_0),
        .O(EX_ReadData1[10]));
  LUT2 #(
    .INIT(4'h8)) 
    \alu_result_out_OBUF[11]_inst_i_4 
       (.I0(DOADO[9]),
        .I1(registers_reg_async_reset_b_0),
        .O(EX_ReadData1[9]));
  LUT2 #(
    .INIT(4'h8)) 
    \alu_result_out_OBUF[11]_inst_i_5 
       (.I0(DOADO[8]),
        .I1(registers_reg_async_reset_b_0),
        .O(EX_ReadData1[8]));
  LUT2 #(
    .INIT(4'h8)) 
    \alu_result_out_OBUF[15]_inst_i_2 
       (.I0(DOADO[15]),
        .I1(registers_reg_async_reset_b_0),
        .O(EX_ReadData1[15]));
  LUT2 #(
    .INIT(4'h8)) 
    \alu_result_out_OBUF[15]_inst_i_3 
       (.I0(DOADO[14]),
        .I1(registers_reg_async_reset_b_0),
        .O(EX_ReadData1[14]));
  LUT2 #(
    .INIT(4'h8)) 
    \alu_result_out_OBUF[15]_inst_i_4 
       (.I0(DOADO[13]),
        .I1(registers_reg_async_reset_b_0),
        .O(EX_ReadData1[13]));
  LUT2 #(
    .INIT(4'h8)) 
    \alu_result_out_OBUF[15]_inst_i_5 
       (.I0(DOADO[12]),
        .I1(registers_reg_async_reset_b_0),
        .O(EX_ReadData1[12]));
  LUT2 #(
    .INIT(4'h8)) 
    \alu_result_out_OBUF[19]_inst_i_2 
       (.I0(DOBDO[3]),
        .I1(registers_reg_async_reset_b_0),
        .O(EX_ReadData1[19]));
  LUT2 #(
    .INIT(4'h8)) 
    \alu_result_out_OBUF[19]_inst_i_3 
       (.I0(DOBDO[2]),
        .I1(registers_reg_async_reset_b_0),
        .O(EX_ReadData1[18]));
  LUT2 #(
    .INIT(4'h8)) 
    \alu_result_out_OBUF[19]_inst_i_4 
       (.I0(DOBDO[1]),
        .I1(registers_reg_async_reset_b_0),
        .O(EX_ReadData1[17]));
  LUT2 #(
    .INIT(4'h8)) 
    \alu_result_out_OBUF[19]_inst_i_5 
       (.I0(DOBDO[0]),
        .I1(registers_reg_async_reset_b_0),
        .O(EX_ReadData1[16]));
  LUT2 #(
    .INIT(4'h8)) 
    \alu_result_out_OBUF[23]_inst_i_2 
       (.I0(DOBDO[7]),
        .I1(registers_reg_async_reset_b_0),
        .O(EX_ReadData1[23]));
  LUT2 #(
    .INIT(4'h8)) 
    \alu_result_out_OBUF[23]_inst_i_3 
       (.I0(DOBDO[6]),
        .I1(registers_reg_async_reset_b_0),
        .O(EX_ReadData1[22]));
  LUT2 #(
    .INIT(4'h8)) 
    \alu_result_out_OBUF[23]_inst_i_4 
       (.I0(DOBDO[5]),
        .I1(registers_reg_async_reset_b_0),
        .O(EX_ReadData1[21]));
  LUT2 #(
    .INIT(4'h8)) 
    \alu_result_out_OBUF[23]_inst_i_5 
       (.I0(DOBDO[4]),
        .I1(registers_reg_async_reset_b_0),
        .O(EX_ReadData1[20]));
  LUT2 #(
    .INIT(4'h8)) 
    \alu_result_out_OBUF[27]_inst_i_2 
       (.I0(DOBDO[11]),
        .I1(registers_reg_async_reset_b_0),
        .O(EX_ReadData1[27]));
  LUT2 #(
    .INIT(4'h8)) 
    \alu_result_out_OBUF[27]_inst_i_3 
       (.I0(DOBDO[10]),
        .I1(registers_reg_async_reset_b_0),
        .O(EX_ReadData1[26]));
  LUT2 #(
    .INIT(4'h8)) 
    \alu_result_out_OBUF[27]_inst_i_4 
       (.I0(DOBDO[9]),
        .I1(registers_reg_async_reset_b_0),
        .O(EX_ReadData1[25]));
  LUT2 #(
    .INIT(4'h8)) 
    \alu_result_out_OBUF[27]_inst_i_5 
       (.I0(DOBDO[8]),
        .I1(registers_reg_async_reset_b_0),
        .O(EX_ReadData1[24]));
  LUT2 #(
    .INIT(4'h8)) 
    \alu_result_out_OBUF[31]_inst_i_2 
       (.I0(DOBDO[14]),
        .I1(registers_reg_async_reset_b_0),
        .O(EX_ReadData1[30]));
  LUT2 #(
    .INIT(4'h8)) 
    \alu_result_out_OBUF[31]_inst_i_3 
       (.I0(DOBDO[13]),
        .I1(registers_reg_async_reset_b_0),
        .O(EX_ReadData1[29]));
  LUT2 #(
    .INIT(4'h8)) 
    \alu_result_out_OBUF[31]_inst_i_4 
       (.I0(DOBDO[12]),
        .I1(registers_reg_async_reset_b_0),
        .O(EX_ReadData1[28]));
  LUT2 #(
    .INIT(4'h8)) 
    \alu_result_out_OBUF[3]_inst_i_2 
       (.I0(DOADO[3]),
        .I1(registers_reg_async_reset_b_0),
        .O(EX_ReadData1[3]));
  LUT2 #(
    .INIT(4'h8)) 
    \alu_result_out_OBUF[3]_inst_i_3 
       (.I0(DOADO[2]),
        .I1(registers_reg_async_reset_b_0),
        .O(EX_ReadData1[2]));
  LUT2 #(
    .INIT(4'h8)) 
    \alu_result_out_OBUF[3]_inst_i_4 
       (.I0(DOADO[1]),
        .I1(registers_reg_async_reset_b_0),
        .O(EX_ReadData1[1]));
  LUT2 #(
    .INIT(4'h8)) 
    \alu_result_out_OBUF[3]_inst_i_5 
       (.I0(DOADO[0]),
        .I1(registers_reg_async_reset_b_0),
        .O(EX_ReadData1[0]));
  LUT2 #(
    .INIT(4'h8)) 
    \alu_result_out_OBUF[7]_inst_i_2 
       (.I0(DOADO[7]),
        .I1(registers_reg_async_reset_b_0),
        .O(EX_ReadData1[7]));
  LUT2 #(
    .INIT(4'h8)) 
    \alu_result_out_OBUF[7]_inst_i_3 
       (.I0(DOADO[6]),
        .I1(registers_reg_async_reset_b_0),
        .O(EX_ReadData1[6]));
  LUT2 #(
    .INIT(4'h8)) 
    \alu_result_out_OBUF[7]_inst_i_4 
       (.I0(DOADO[5]),
        .I1(registers_reg_async_reset_b_0),
        .O(EX_ReadData1[5]));
  LUT2 #(
    .INIT(4'h8)) 
    \alu_result_out_OBUF[7]_inst_i_5 
       (.I0(DOADO[4]),
        .I1(registers_reg_async_reset_b_0),
        .O(EX_ReadData1[4]));
  (* IS_CLOCK_GATED *) 
  (* \MEM.PORTA.DATA_BIT_LAYOUT  = "p0_d32" *) 
  (* \MEM.PORTB.DATA_BIT_LAYOUT  = "p0_d32" *) 
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-6 {cell *THIS*}} {SYNTH-7 {cell *THIS*}}" *) 
  (* POWER_OPTED_CE = "ENBWREN=NEW" *) 
  (* RTL_RAM_BITS = "1024" *) 
  (* RTL_RAM_NAME = "top_risc_processor/RF/registers_reg" *) 
  (* RTL_RAM_STYLE = "auto" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "511" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "0" *) 
  (* ram_slice_end = "31" *) 
  RAMB18E1 #(
    .DOA_REG(0),
    .DOB_REG(0),
    .INITP_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_10(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_11(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_12(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_13(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_14(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_15(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_16(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_17(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_18(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_19(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_20(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_21(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_22(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_23(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_24(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_25(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_26(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_27(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_28(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_29(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_30(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_31(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_32(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_33(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_34(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_35(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_36(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_37(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_38(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_39(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_A(18'h00000),
    .INIT_B(18'h00000),
    .INIT_FILE("NONE"),
    .RAM_MODE("SDP"),
    .RDADDR_COLLISION_HWCONFIG("DELAYED_WRITE"),
    .READ_WIDTH_A(36),
    .READ_WIDTH_B(0),
    .RSTREG_PRIORITY_A("RSTREG"),
    .RSTREG_PRIORITY_B("RSTREG"),
    .SIM_COLLISION_CHECK("ALL"),
    .SIM_DEVICE("7SERIES"),
    .SRVAL_A(18'h00000),
    .SRVAL_B(18'h00000),
    .WRITE_MODE_A("READ_FIRST"),
    .WRITE_MODE_B("READ_FIRST"),
    .WRITE_WIDTH_A(0),
    .WRITE_WIDTH_B(36)) 
    registers_reg_1
       (.ADDRARDADDR({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b1,1'b1,1'b1,1'b1,1'b1}),
        .ADDRBWRADDR({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b1,1'b1,1'b1,1'b1,1'b1}),
        .CLKARDCLK(clk_IBUF_BUFG),
        .CLKBWRCLK(clk_IBUF_BUFG),
        .DIADI(WB_ALU_Result[15:0]),
        .DIBDI(WB_ALU_Result[31:16]),
        .DIPADIP({1'b1,1'b1}),
        .DIPBDIP({1'b1,1'b1}),
        .DOADO(DOADO),
        .DOBDO(DOBDO),
        .DOPADOP(NLW_registers_reg_1_DOPADOP_UNCONNECTED[1:0]),
        .DOPBDOP(NLW_registers_reg_1_DOPBDOP_UNCONNECTED[1:0]),
        .ENARDEN(1'b1),
        .ENBWREN(RegWrite_out),
        .REGCEAREGCE(1'b0),
        .REGCEB(1'b0),
        .RSTRAMARSTRAM(reset_IBUF),
        .RSTRAMB(1'b0),
        .RSTREGARSTREG(1'b0),
        .RSTREGB(1'b0),
        .WEA({1'b0,1'b0}),
        .WEBWE({RegWrite_out,RegWrite_out,RegWrite_out,RegWrite_out}));
  (* IS_CLOCK_GATED *) 
  (* \MEM.PORTA.DATA_BIT_LAYOUT  = "p0_d32" *) 
  (* \MEM.PORTB.DATA_BIT_LAYOUT  = "p0_d32" *) 
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-6 {cell *THIS*}} {SYNTH-7 {cell *THIS*}}" *) 
  (* POWER_OPTED_CE = "ENBWREN=NEW" *) 
  (* RTL_RAM_BITS = "1024" *) 
  (* RTL_RAM_NAME = "top_risc_processor/RF/registers_reg" *) 
  (* RTL_RAM_STYLE = "auto" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "511" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "0" *) 
  (* ram_slice_end = "31" *) 
  RAMB18E1 #(
    .DOA_REG(0),
    .DOB_REG(0),
    .INITP_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_10(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_11(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_12(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_13(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_14(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_15(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_16(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_17(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_18(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_19(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_20(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_21(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_22(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_23(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_24(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_25(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_26(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_27(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_28(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_29(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_30(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_31(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_32(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_33(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_34(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_35(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_36(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_37(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_38(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_39(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_A(18'h00000),
    .INIT_B(18'h00000),
    .INIT_FILE("NONE"),
    .RAM_MODE("SDP"),
    .RDADDR_COLLISION_HWCONFIG("DELAYED_WRITE"),
    .READ_WIDTH_A(36),
    .READ_WIDTH_B(0),
    .RSTREG_PRIORITY_A("RSTREG"),
    .RSTREG_PRIORITY_B("RSTREG"),
    .SIM_COLLISION_CHECK("ALL"),
    .SIM_DEVICE("7SERIES"),
    .SRVAL_A(18'h00000),
    .SRVAL_B(18'h00000),
    .WRITE_MODE_A("READ_FIRST"),
    .WRITE_MODE_B("READ_FIRST"),
    .WRITE_WIDTH_A(0),
    .WRITE_WIDTH_B(36)) 
    registers_reg_2
       (.ADDRARDADDR({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b1,1'b1,1'b1,1'b1,1'b1}),
        .ADDRBWRADDR({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b1,1'b1,1'b1,1'b1,1'b1}),
        .CLKARDCLK(clk_IBUF_BUFG),
        .CLKBWRCLK(clk_IBUF_BUFG),
        .DIADI(WB_ALU_Result[15:0]),
        .DIBDI(WB_ALU_Result[31:16]),
        .DIPADIP({1'b1,1'b1}),
        .DIPBDIP({1'b1,1'b1}),
        .DOADO(registers_reg_2_0),
        .DOBDO(registers_reg_2_1),
        .DOPADOP(NLW_registers_reg_2_DOPADOP_UNCONNECTED[1:0]),
        .DOPBDOP(NLW_registers_reg_2_DOPBDOP_UNCONNECTED[1:0]),
        .ENARDEN(1'b1),
        .ENBWREN(RegWrite_out),
        .REGCEAREGCE(1'b0),
        .REGCEB(1'b0),
        .RSTRAMARSTRAM(reset_IBUF),
        .RSTRAMB(1'b0),
        .RSTREGARSTREG(1'b0),
        .RSTREGB(1'b0),
        .WEA({1'b0,1'b0}),
        .WEBWE({RegWrite_out,RegWrite_out,RegWrite_out,RegWrite_out}));
  FDCE #(
    .INIT(1'b0)) 
    registers_reg_async_reset_b
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(1'b1),
        .Q(registers_reg_async_reset_b_0));
endmodule

(* ECO_CHECKSUM = "6d15e146" *) (* POWER_OPT_BRAM_CDC = "0" *) (* POWER_OPT_BRAM_SR_ADDR = "0" *) 
(* POWER_OPT_LOOPED_NET_PERCENTAGE = "0" *) 
(* NotValidForBitStream *)
(* \DesignAttr:ENABLE_NOC_NETLIST_VIEW  *) 
(* \DesignAttr:ENABLE_AIE_NETLIST_VIEW  *) 
module top_risc_processor
   (clk,
    reset,
    pc_out,
    instruction_out,
    alu_result_out);
  input clk;
  input reset;
  output [31:0]pc_out;
  output [31:0]instruction_out;
  output [31:0]alu_result_out;

  wire EXMEM_n_0;
  wire MEMWB_n_0;
  wire [31:0]MEM_ALU_Result;
  wire RF_n_0;
  wire RF_n_1;
  wire RF_n_10;
  wire RF_n_11;
  wire RF_n_12;
  wire RF_n_13;
  wire RF_n_14;
  wire RF_n_15;
  wire RF_n_16;
  wire RF_n_17;
  wire RF_n_18;
  wire RF_n_19;
  wire RF_n_2;
  wire RF_n_20;
  wire RF_n_21;
  wire RF_n_22;
  wire RF_n_23;
  wire RF_n_24;
  wire RF_n_25;
  wire RF_n_26;
  wire RF_n_27;
  wire RF_n_28;
  wire RF_n_29;
  wire RF_n_3;
  wire RF_n_30;
  wire RF_n_31;
  wire RF_n_32;
  wire RF_n_33;
  wire RF_n_34;
  wire RF_n_35;
  wire RF_n_36;
  wire RF_n_37;
  wire RF_n_38;
  wire RF_n_39;
  wire RF_n_4;
  wire RF_n_40;
  wire RF_n_41;
  wire RF_n_42;
  wire RF_n_43;
  wire RF_n_44;
  wire RF_n_45;
  wire RF_n_46;
  wire RF_n_47;
  wire RF_n_48;
  wire RF_n_49;
  wire RF_n_5;
  wire RF_n_50;
  wire RF_n_51;
  wire RF_n_52;
  wire RF_n_53;
  wire RF_n_54;
  wire RF_n_55;
  wire RF_n_56;
  wire RF_n_57;
  wire RF_n_58;
  wire RF_n_59;
  wire RF_n_6;
  wire RF_n_60;
  wire RF_n_61;
  wire RF_n_62;
  wire RF_n_63;
  wire RF_n_7;
  wire RF_n_8;
  wire RF_n_9;
  wire RF_n_95;
  wire RegWrite_out;
  wire [31:0]WB_ALU_Result;
  wire [31:0]alu_result_out;
  wire [31:0]alu_result_out_OBUF;
  wire clk;
  wire clk_IBUF;
  wire clk_IBUF_BUFG;
  wire [30:0]ex_read_data1;
  wire [31:0]instruction_out;
  wire [31:0]pc_out;
  wire [31:2]pc_out_OBUF;
  wire reset;
  wire reset_IBUF;

  alu ALU
       (.DOADO({RF_n_0,RF_n_1,RF_n_2,RF_n_3,RF_n_4,RF_n_5,RF_n_6,RF_n_7,RF_n_8,RF_n_9,RF_n_10,RF_n_11,RF_n_12,RF_n_13,RF_n_14,RF_n_15}),
        .DOBDO({RF_n_16,RF_n_17,RF_n_18,RF_n_19,RF_n_20,RF_n_21,RF_n_22,RF_n_23,RF_n_24,RF_n_25,RF_n_26,RF_n_27,RF_n_28,RF_n_29,RF_n_30,RF_n_31}),
        .EX_ReadData1(ex_read_data1),
        .\MEM_ALU_Result_reg[15] ({RF_n_32,RF_n_33,RF_n_34,RF_n_35,RF_n_36,RF_n_37,RF_n_38,RF_n_39,RF_n_40,RF_n_41,RF_n_42,RF_n_43,RF_n_44,RF_n_45,RF_n_46,RF_n_47}),
        .\MEM_ALU_Result_reg[31] ({RF_n_48,RF_n_49,RF_n_50,RF_n_51,RF_n_52,RF_n_53,RF_n_54,RF_n_55,RF_n_56,RF_n_57,RF_n_58,RF_n_59,RF_n_60,RF_n_61,RF_n_62,RF_n_63}),
        .\MEM_ALU_Result_reg[3] (RF_n_95),
        .data0(alu_result_out_OBUF));
  EX_MEM EXMEM
       (.D(alu_result_out_OBUF),
        .Q(MEM_ALU_Result),
        .RegWrite_out(RegWrite_out),
        .RegWrite_out_reg_0(EXMEM_n_0),
        .clk_IBUF_BUFG(clk_IBUF_BUFG),
        .reset_IBUF(reset_IBUF));
  ID_EX IDEX
       (.RegWrite_out(RegWrite_out),
        .clk_IBUF_BUFG(clk_IBUF_BUFG),
        .reset_IBUF(reset_IBUF));
  MEM_WB MEMWB
       (.D(MEM_ALU_Result),
        .Q(WB_ALU_Result),
        .RegWrite_out(MEMWB_n_0),
        .RegWrite_out_reg_0(EXMEM_n_0),
        .clk_IBUF_BUFG(clk_IBUF_BUFG),
        .reset_IBUF(reset_IBUF));
  program_counter PC
       (.clk_IBUF_BUFG(clk_IBUF_BUFG),
        .out(pc_out_OBUF),
        .reset_IBUF(reset_IBUF));
  register_file RF
       (.DOADO({RF_n_0,RF_n_1,RF_n_2,RF_n_3,RF_n_4,RF_n_5,RF_n_6,RF_n_7,RF_n_8,RF_n_9,RF_n_10,RF_n_11,RF_n_12,RF_n_13,RF_n_14,RF_n_15}),
        .DOBDO({RF_n_16,RF_n_17,RF_n_18,RF_n_19,RF_n_20,RF_n_21,RF_n_22,RF_n_23,RF_n_24,RF_n_25,RF_n_26,RF_n_27,RF_n_28,RF_n_29,RF_n_30,RF_n_31}),
        .EX_ReadData1(ex_read_data1),
        .RegWrite_out(MEMWB_n_0),
        .WB_ALU_Result(WB_ALU_Result),
        .clk_IBUF_BUFG(clk_IBUF_BUFG),
        .registers_reg_2_0({RF_n_32,RF_n_33,RF_n_34,RF_n_35,RF_n_36,RF_n_37,RF_n_38,RF_n_39,RF_n_40,RF_n_41,RF_n_42,RF_n_43,RF_n_44,RF_n_45,RF_n_46,RF_n_47}),
        .registers_reg_2_1({RF_n_48,RF_n_49,RF_n_50,RF_n_51,RF_n_52,RF_n_53,RF_n_54,RF_n_55,RF_n_56,RF_n_57,RF_n_58,RF_n_59,RF_n_60,RF_n_61,RF_n_62,RF_n_63}),
        .registers_reg_async_reset_b_0(RF_n_95),
        .reset_IBUF(reset_IBUF));
  OBUF \alu_result_out_OBUF[0]_inst 
       (.I(alu_result_out_OBUF[0]),
        .O(alu_result_out[0]));
  OBUF \alu_result_out_OBUF[10]_inst 
       (.I(alu_result_out_OBUF[10]),
        .O(alu_result_out[10]));
  OBUF \alu_result_out_OBUF[11]_inst 
       (.I(alu_result_out_OBUF[11]),
        .O(alu_result_out[11]));
  OBUF \alu_result_out_OBUF[12]_inst 
       (.I(alu_result_out_OBUF[12]),
        .O(alu_result_out[12]));
  OBUF \alu_result_out_OBUF[13]_inst 
       (.I(alu_result_out_OBUF[13]),
        .O(alu_result_out[13]));
  OBUF \alu_result_out_OBUF[14]_inst 
       (.I(alu_result_out_OBUF[14]),
        .O(alu_result_out[14]));
  OBUF \alu_result_out_OBUF[15]_inst 
       (.I(alu_result_out_OBUF[15]),
        .O(alu_result_out[15]));
  OBUF \alu_result_out_OBUF[16]_inst 
       (.I(alu_result_out_OBUF[16]),
        .O(alu_result_out[16]));
  OBUF \alu_result_out_OBUF[17]_inst 
       (.I(alu_result_out_OBUF[17]),
        .O(alu_result_out[17]));
  OBUF \alu_result_out_OBUF[18]_inst 
       (.I(alu_result_out_OBUF[18]),
        .O(alu_result_out[18]));
  OBUF \alu_result_out_OBUF[19]_inst 
       (.I(alu_result_out_OBUF[19]),
        .O(alu_result_out[19]));
  OBUF \alu_result_out_OBUF[1]_inst 
       (.I(alu_result_out_OBUF[1]),
        .O(alu_result_out[1]));
  OBUF \alu_result_out_OBUF[20]_inst 
       (.I(alu_result_out_OBUF[20]),
        .O(alu_result_out[20]));
  OBUF \alu_result_out_OBUF[21]_inst 
       (.I(alu_result_out_OBUF[21]),
        .O(alu_result_out[21]));
  OBUF \alu_result_out_OBUF[22]_inst 
       (.I(alu_result_out_OBUF[22]),
        .O(alu_result_out[22]));
  OBUF \alu_result_out_OBUF[23]_inst 
       (.I(alu_result_out_OBUF[23]),
        .O(alu_result_out[23]));
  OBUF \alu_result_out_OBUF[24]_inst 
       (.I(alu_result_out_OBUF[24]),
        .O(alu_result_out[24]));
  OBUF \alu_result_out_OBUF[25]_inst 
       (.I(alu_result_out_OBUF[25]),
        .O(alu_result_out[25]));
  OBUF \alu_result_out_OBUF[26]_inst 
       (.I(alu_result_out_OBUF[26]),
        .O(alu_result_out[26]));
  OBUF \alu_result_out_OBUF[27]_inst 
       (.I(alu_result_out_OBUF[27]),
        .O(alu_result_out[27]));
  OBUF \alu_result_out_OBUF[28]_inst 
       (.I(alu_result_out_OBUF[28]),
        .O(alu_result_out[28]));
  OBUF \alu_result_out_OBUF[29]_inst 
       (.I(alu_result_out_OBUF[29]),
        .O(alu_result_out[29]));
  OBUF \alu_result_out_OBUF[2]_inst 
       (.I(alu_result_out_OBUF[2]),
        .O(alu_result_out[2]));
  OBUF \alu_result_out_OBUF[30]_inst 
       (.I(alu_result_out_OBUF[30]),
        .O(alu_result_out[30]));
  OBUF \alu_result_out_OBUF[31]_inst 
       (.I(alu_result_out_OBUF[31]),
        .O(alu_result_out[31]));
  OBUF \alu_result_out_OBUF[3]_inst 
       (.I(alu_result_out_OBUF[3]),
        .O(alu_result_out[3]));
  OBUF \alu_result_out_OBUF[4]_inst 
       (.I(alu_result_out_OBUF[4]),
        .O(alu_result_out[4]));
  OBUF \alu_result_out_OBUF[5]_inst 
       (.I(alu_result_out_OBUF[5]),
        .O(alu_result_out[5]));
  OBUF \alu_result_out_OBUF[6]_inst 
       (.I(alu_result_out_OBUF[6]),
        .O(alu_result_out[6]));
  OBUF \alu_result_out_OBUF[7]_inst 
       (.I(alu_result_out_OBUF[7]),
        .O(alu_result_out[7]));
  OBUF \alu_result_out_OBUF[8]_inst 
       (.I(alu_result_out_OBUF[8]),
        .O(alu_result_out[8]));
  OBUF \alu_result_out_OBUF[9]_inst 
       (.I(alu_result_out_OBUF[9]),
        .O(alu_result_out[9]));
  BUFG clk_IBUF_BUFG_inst
       (.I(clk_IBUF),
        .O(clk_IBUF_BUFG));
  IBUF clk_IBUF_inst
       (.I(clk),
        .O(clk_IBUF));
  OBUF \instruction_out_OBUF[0]_inst 
       (.I(1'b0),
        .O(instruction_out[0]));
  OBUF \instruction_out_OBUF[10]_inst 
       (.I(1'b0),
        .O(instruction_out[10]));
  OBUF \instruction_out_OBUF[11]_inst 
       (.I(1'b0),
        .O(instruction_out[11]));
  OBUF \instruction_out_OBUF[12]_inst 
       (.I(1'b0),
        .O(instruction_out[12]));
  OBUF \instruction_out_OBUF[13]_inst 
       (.I(1'b0),
        .O(instruction_out[13]));
  OBUF \instruction_out_OBUF[14]_inst 
       (.I(1'b0),
        .O(instruction_out[14]));
  OBUF \instruction_out_OBUF[15]_inst 
       (.I(1'b0),
        .O(instruction_out[15]));
  OBUF \instruction_out_OBUF[16]_inst 
       (.I(1'b0),
        .O(instruction_out[16]));
  OBUF \instruction_out_OBUF[17]_inst 
       (.I(1'b0),
        .O(instruction_out[17]));
  OBUF \instruction_out_OBUF[18]_inst 
       (.I(1'b0),
        .O(instruction_out[18]));
  OBUF \instruction_out_OBUF[19]_inst 
       (.I(1'b0),
        .O(instruction_out[19]));
  OBUF \instruction_out_OBUF[1]_inst 
       (.I(1'b0),
        .O(instruction_out[1]));
  OBUF \instruction_out_OBUF[20]_inst 
       (.I(1'b0),
        .O(instruction_out[20]));
  OBUF \instruction_out_OBUF[21]_inst 
       (.I(1'b0),
        .O(instruction_out[21]));
  OBUF \instruction_out_OBUF[22]_inst 
       (.I(1'b0),
        .O(instruction_out[22]));
  OBUF \instruction_out_OBUF[23]_inst 
       (.I(1'b0),
        .O(instruction_out[23]));
  OBUF \instruction_out_OBUF[24]_inst 
       (.I(1'b0),
        .O(instruction_out[24]));
  OBUF \instruction_out_OBUF[25]_inst 
       (.I(1'b0),
        .O(instruction_out[25]));
  OBUF \instruction_out_OBUF[26]_inst 
       (.I(1'b0),
        .O(instruction_out[26]));
  OBUF \instruction_out_OBUF[27]_inst 
       (.I(1'b0),
        .O(instruction_out[27]));
  OBUF \instruction_out_OBUF[28]_inst 
       (.I(1'b0),
        .O(instruction_out[28]));
  OBUF \instruction_out_OBUF[29]_inst 
       (.I(1'b0),
        .O(instruction_out[29]));
  OBUF \instruction_out_OBUF[2]_inst 
       (.I(1'b0),
        .O(instruction_out[2]));
  OBUF \instruction_out_OBUF[30]_inst 
       (.I(1'b0),
        .O(instruction_out[30]));
  OBUF \instruction_out_OBUF[31]_inst 
       (.I(1'b0),
        .O(instruction_out[31]));
  OBUF \instruction_out_OBUF[3]_inst 
       (.I(1'b0),
        .O(instruction_out[3]));
  OBUF \instruction_out_OBUF[4]_inst 
       (.I(1'b0),
        .O(instruction_out[4]));
  OBUF \instruction_out_OBUF[5]_inst 
       (.I(1'b0),
        .O(instruction_out[5]));
  OBUF \instruction_out_OBUF[6]_inst 
       (.I(1'b0),
        .O(instruction_out[6]));
  OBUF \instruction_out_OBUF[7]_inst 
       (.I(1'b0),
        .O(instruction_out[7]));
  OBUF \instruction_out_OBUF[8]_inst 
       (.I(1'b0),
        .O(instruction_out[8]));
  OBUF \instruction_out_OBUF[9]_inst 
       (.I(1'b0),
        .O(instruction_out[9]));
  OBUF \pc_out_OBUF[0]_inst 
       (.I(1'b0),
        .O(pc_out[0]));
  OBUF \pc_out_OBUF[10]_inst 
       (.I(pc_out_OBUF[10]),
        .O(pc_out[10]));
  OBUF \pc_out_OBUF[11]_inst 
       (.I(pc_out_OBUF[11]),
        .O(pc_out[11]));
  OBUF \pc_out_OBUF[12]_inst 
       (.I(pc_out_OBUF[12]),
        .O(pc_out[12]));
  OBUF \pc_out_OBUF[13]_inst 
       (.I(pc_out_OBUF[13]),
        .O(pc_out[13]));
  OBUF \pc_out_OBUF[14]_inst 
       (.I(pc_out_OBUF[14]),
        .O(pc_out[14]));
  OBUF \pc_out_OBUF[15]_inst 
       (.I(pc_out_OBUF[15]),
        .O(pc_out[15]));
  OBUF \pc_out_OBUF[16]_inst 
       (.I(pc_out_OBUF[16]),
        .O(pc_out[16]));
  OBUF \pc_out_OBUF[17]_inst 
       (.I(pc_out_OBUF[17]),
        .O(pc_out[17]));
  OBUF \pc_out_OBUF[18]_inst 
       (.I(pc_out_OBUF[18]),
        .O(pc_out[18]));
  OBUF \pc_out_OBUF[19]_inst 
       (.I(pc_out_OBUF[19]),
        .O(pc_out[19]));
  OBUF \pc_out_OBUF[1]_inst 
       (.I(1'b0),
        .O(pc_out[1]));
  OBUF \pc_out_OBUF[20]_inst 
       (.I(pc_out_OBUF[20]),
        .O(pc_out[20]));
  OBUF \pc_out_OBUF[21]_inst 
       (.I(pc_out_OBUF[21]),
        .O(pc_out[21]));
  OBUF \pc_out_OBUF[22]_inst 
       (.I(pc_out_OBUF[22]),
        .O(pc_out[22]));
  OBUF \pc_out_OBUF[23]_inst 
       (.I(pc_out_OBUF[23]),
        .O(pc_out[23]));
  OBUF \pc_out_OBUF[24]_inst 
       (.I(pc_out_OBUF[24]),
        .O(pc_out[24]));
  OBUF \pc_out_OBUF[25]_inst 
       (.I(pc_out_OBUF[25]),
        .O(pc_out[25]));
  OBUF \pc_out_OBUF[26]_inst 
       (.I(pc_out_OBUF[26]),
        .O(pc_out[26]));
  OBUF \pc_out_OBUF[27]_inst 
       (.I(pc_out_OBUF[27]),
        .O(pc_out[27]));
  OBUF \pc_out_OBUF[28]_inst 
       (.I(pc_out_OBUF[28]),
        .O(pc_out[28]));
  OBUF \pc_out_OBUF[29]_inst 
       (.I(pc_out_OBUF[29]),
        .O(pc_out[29]));
  OBUF \pc_out_OBUF[2]_inst 
       (.I(pc_out_OBUF[2]),
        .O(pc_out[2]));
  OBUF \pc_out_OBUF[30]_inst 
       (.I(pc_out_OBUF[30]),
        .O(pc_out[30]));
  OBUF \pc_out_OBUF[31]_inst 
       (.I(pc_out_OBUF[31]),
        .O(pc_out[31]));
  OBUF \pc_out_OBUF[3]_inst 
       (.I(pc_out_OBUF[3]),
        .O(pc_out[3]));
  OBUF \pc_out_OBUF[4]_inst 
       (.I(pc_out_OBUF[4]),
        .O(pc_out[4]));
  OBUF \pc_out_OBUF[5]_inst 
       (.I(pc_out_OBUF[5]),
        .O(pc_out[5]));
  OBUF \pc_out_OBUF[6]_inst 
       (.I(pc_out_OBUF[6]),
        .O(pc_out[6]));
  OBUF \pc_out_OBUF[7]_inst 
       (.I(pc_out_OBUF[7]),
        .O(pc_out[7]));
  OBUF \pc_out_OBUF[8]_inst 
       (.I(pc_out_OBUF[8]),
        .O(pc_out[8]));
  OBUF \pc_out_OBUF[9]_inst 
       (.I(pc_out_OBUF[9]),
        .O(pc_out[9]));
  IBUF reset_IBUF_inst
       (.I(reset),
        .O(reset_IBUF));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
