`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 03.08.2026 00:13:21
// Design Name: 
// Module Name: top_risc_processor_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps

module top_risc_processor_tb;

reg clk;
reg reset;

wire [31:0] pc_out;
wire [31:0] instruction_out;
wire [31:0] alu_result_out;

top_risc_processor DUT(
    .clk(clk),
    .reset(reset),
    .pc_out(pc_out),
    .instruction_out(instruction_out),
    .alu_result_out(alu_result_out)
);

always #5 clk = ~clk;

initial
begin
    clk = 0;
    reset = 1;

    #20;
    reset = 0;

    #200;

    $finish;
end

initial
begin
    $monitor(
        "Time=%0t | PC=%h | Instruction=%h | ALU=%h",
        $time,
        pc_out,
        instruction_out,
        alu_result_out
    );
end

endmodule
