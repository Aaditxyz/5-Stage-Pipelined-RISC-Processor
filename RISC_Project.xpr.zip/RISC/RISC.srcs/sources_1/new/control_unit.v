`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 02.08.2026 22:24:05
// Design Name: 
// Module Name: control_unit
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module control_unit(
    input [5:0] opcode,

    output reg RegWrite,
    output reg MemRead,
    output reg MemWrite,
    output reg MemtoReg,
    output reg ALUSrc,
    output reg Branch,
    output reg [2:0] ALU_Control
);

always @(*)
begin

    RegWrite = 1'b0;
    MemRead = 1'b0;
    MemWrite = 1'b0;
    MemtoReg = 1'b0;
    ALUSrc = 1'b0;
    Branch = 1'b0;
    ALU_Control = 3'b000;

    case(opcode)

        6'b000000:
        begin
            RegWrite = 1'b1;
            ALUSrc = 1'b0;
            ALU_Control = 3'b000;
        end

        6'b100011:
        begin
            RegWrite = 1'b1;
            MemRead = 1'b1;
            MemtoReg = 1'b1;
            ALUSrc = 1'b1;
            ALU_Control = 3'b000;
        end

        6'b101011:
        begin
            MemWrite = 1'b1;
            ALUSrc = 1'b1;
            ALU_Control = 3'b000;
        end

        6'b000100:
        begin
            Branch = 1'b1;
            ALU_Control = 3'b001;
        end

        default:
        begin
            RegWrite = 1'b0;
            MemRead = 1'b0;
            MemWrite = 1'b0;
            MemtoReg = 1'b0;
            ALUSrc = 1'b0;
            Branch = 1'b0;
            ALU_Control = 3'b000;
        end

    endcase

end

endmodule
