`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 02.08.2026 22:50:08
// Design Name: 
// Module Name: MEM_WB
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module MEM_WB(
    input clk,
    input reset,

    input [31:0] MEM_ALU_Result,
    input [31:0] MEM_ReadData,
    input [4:0] MEM_rd,

    input RegWrite_in,
    input MemtoReg_in,

    output reg [31:0] WB_ALU_Result,
    output reg [31:0] WB_ReadData,
    output reg [4:0] WB_rd,

    output reg RegWrite_out,
    output reg MemtoReg_out
);

always @(posedge clk or posedge reset)
begin
    if(reset)
    begin
        WB_ALU_Result <= 32'd0;
        WB_ReadData <= 32'd0;
        WB_rd <= 5'd0;

        RegWrite_out <= 1'b0;
        MemtoReg_out <= 1'b0;
    end
    else
    begin
        WB_ALU_Result <= MEM_ALU_Result;
        WB_ReadData <= MEM_ReadData;
        WB_rd <= MEM_rd;

        RegWrite_out <= RegWrite_in;
        MemtoReg_out <= MemtoReg_in;
    end
end

endmodule
