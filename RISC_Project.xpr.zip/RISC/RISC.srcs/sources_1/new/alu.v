`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 02.08.2026 22:22:57
// Design Name: 
// Module Name: alu
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module alu(
    input [31:0] A,
    input [31:0] B,
    input [2:0] ALU_Control,
    output reg [31:0] Result,
    output Zero
);

always @(*)
begin
    case(ALU_Control)
        3'b000: Result = A + B;   // ADD
        3'b001: Result = A - B;   // SUB
        3'b010: Result = A & B;   // AND
        3'b011: Result = A | B;   // OR
        3'b100: Result = A ^ B;   // XOR
        3'b101: Result = ~(A | B); // NOR
        default: Result = 32'd0;
    endcase
end

assign Zero = (Result == 32'd0);

endmodule