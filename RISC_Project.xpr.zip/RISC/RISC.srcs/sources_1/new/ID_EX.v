`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 02.08.2026 22:43:57
// Design Name: 
// Module Name: ID_EX
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////



module ID_EX(
    input clk,
    input reset,

    input [31:0] ID_PC,
    input [31:0] ID_ReadData1,
    input [31:0] ID_ReadData2,
    input [31:0] ID_Immediate,
    input [4:0] ID_rd,

    input RegWrite_in,
    input MemRead_in,
    input MemWrite_in,
    input MemtoReg_in,
    input ALUSrc_in,
    input Branch_in,
    input [2:0] ALU_Control_in,

    output reg [31:0] EX_PC,
    output reg [31:0] EX_ReadData1,
    output reg [31:0] EX_ReadData2,
    output reg [31:0] EX_Immediate,
    output reg [4:0] EX_rd,

    output reg RegWrite_out,
    output reg MemRead_out,
    output reg MemWrite_out,
    output reg MemtoReg_out,
    output reg ALUSrc_out,
    output reg Branch_out,
    output reg [2:0] ALU_Control_out
);

always @(posedge clk or posedge reset)
begin
    if(reset)
    begin
        EX_PC <= 32'd0;
        EX_ReadData1 <= 32'd0;
        EX_ReadData2 <= 32'd0;
        EX_Immediate <= 32'd0;
        EX_rd <= 5'd0;

        RegWrite_out <= 1'b0;
        MemRead_out <= 1'b0;
        MemWrite_out <= 1'b0;
        MemtoReg_out <= 1'b0;
        ALUSrc_out <= 1'b0;
        Branch_out <= 1'b0;
        ALU_Control_out <= 3'b000;
    end
    else
    begin
        EX_PC <= ID_PC;
        EX_ReadData1 <= ID_ReadData1;
        EX_ReadData2 <= ID_ReadData2;
        EX_Immediate <= ID_Immediate;
        EX_rd <= ID_rd;

        RegWrite_out <= RegWrite_in;
        MemRead_out <= MemRead_in;
        MemWrite_out <= MemWrite_in;
        MemtoReg_out <= MemtoReg_in;
        ALUSrc_out <= ALUSrc_in;
        Branch_out <= Branch_in;
        ALU_Control_out <= ALU_Control_in;
    end
end

endmodule