`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 02.08.2026 22:26:44
// Design Name: 
// Module Name: IF_ID
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module IF_ID(
    input clk,
    input reset,
    input [31:0] IF_PC,
    input [31:0] IF_Instruction,
    output reg [31:0] ID_PC,
    output reg [31:0] ID_Instruction
);

always @(posedge clk or posedge reset)
begin
    if(reset)
    begin
        ID_PC <= 32'd0;
        ID_Instruction <= 32'd0;
    end
    else
    begin
        ID_PC <= IF_PC;
        ID_Instruction <= IF_Instruction;
    end
end

endmodule
