`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 02.08.2026 23:09:19
// Design Name: 
// Module Name: top_risc_processor
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module top_risc_processor(
    input clk,
    input reset,
    output [31:0] pc_out,
    output [31:0] instruction_out,
    output [31:0] alu_result_out
);
wire [31:0] pc;
wire [31:0] next_pc;
wire [31:0] instruction;

wire [31:0] id_pc;
wire [31:0] id_instruction;

wire [5:0] opcode;
wire [4:0] rs;
wire [4:0] rt;
wire [4:0] rd;
wire [15:0] immediate;

wire [31:0] read_data1;
wire [31:0] read_data2;
wire [31:0] sign_ext_data;

wire [31:0] ex_pc;
wire [31:0] ex_read_data1;
wire [31:0] ex_read_data2;
wire [31:0] ex_immediate;

wire [4:0] ex_rd;
wire [4:0] mem_rd;
wire [4:0] wb_rd;

wire [31:0] alu_result;
wire zero;

wire [31:0] mem_alu_result;
wire [31:0] mem_write_data;
wire [31:0] mem_read_data;

wire [31:0] wb_alu_result;
wire [31:0] wb_read_data;

wire RegWrite;
wire MemRead;
wire MemWrite;
wire MemtoReg;
wire ALUSrc;
wire Branch;
wire [2:0] ALU_Control;

wire RegWrite_EX;
wire MemRead_EX;
wire MemWrite_EX;
wire MemtoReg_EX;
wire ALUSrc_EX;
wire Branch_EX;
wire [2:0] ALU_Control_EX;

wire RegWrite_MEM;
wire MemRead_MEM;
wire MemWrite_MEM;
wire MemtoReg_MEM;

wire RegWrite_WB;
wire MemtoReg_WB;
assign next_pc = pc + 4;

assign opcode = id_instruction[31:26];
assign rs = id_instruction[25:21];
assign rt = id_instruction[20:16];
assign rd = id_instruction[15:11];
assign immediate = id_instruction[15:0];
program_counter PC(
    .clk(clk),
    .reset(reset),
    .next_pc(next_pc),
    .pc(pc)
);

instruction_memory IM(
    .address(pc),
    .instruction(instruction)
);

IF_ID IFID(
    .clk(clk),
    .reset(reset),
    .IF_PC(pc),
    .IF_Instruction(instruction),
    .ID_PC(id_pc),
    .ID_Instruction(id_instruction)
);

control_unit CU(
    .opcode(opcode),
    .RegWrite(RegWrite),
    .MemRead(MemRead),
    .MemWrite(MemWrite),
    .MemtoReg(MemtoReg),
    .ALUSrc(ALUSrc),
    .Branch(Branch),
    .ALU_Control(ALU_Control)
);

register_file RF(
    .clk(clk),
    .reg_write(RegWrite_WB),
    .rs(rs),
    .rt(rt),
    .rd(wb_rd),
    .write_data(wb_alu_result),
    .read_data1(read_data1),
    .read_data2(read_data2)
);

sign_extend SE(
    .immediate(immediate),
    .extended_immediate(sign_ext_data)
);
ID_EX IDEX(
    .clk(clk),
    .reset(reset),

    .ID_PC(id_pc),
    .ID_ReadData1(read_data1),
    .ID_ReadData2(read_data2),
    .ID_Immediate(sign_ext_data),
    .ID_rd(rd),

    .RegWrite_in(RegWrite),
    .MemRead_in(MemRead),
    .MemWrite_in(MemWrite),
    .MemtoReg_in(MemtoReg),
    .ALUSrc_in(ALUSrc),
    .Branch_in(Branch),
    .ALU_Control_in(ALU_Control),

    .EX_PC(ex_pc),
    .EX_ReadData1(ex_read_data1),
    .EX_ReadData2(ex_read_data2),
    .EX_Immediate(ex_immediate),
    .EX_rd(ex_rd),

    .RegWrite_out(RegWrite_EX),
    .MemRead_out(MemRead_EX),
    .MemWrite_out(MemWrite_EX),
    .MemtoReg_out(MemtoReg_EX),
    .ALUSrc_out(ALUSrc_EX),
    .Branch_out(Branch_EX),
    .ALU_Control_out(ALU_Control_EX)
);

alu ALU(
    .A(ex_read_data1),
    .B(ex_read_data2),
    .ALU_Control(ALU_Control_EX),
    .Result(alu_result),
    .Zero(zero)
);
EX_MEM EXMEM(
    .clk(clk),
    .reset(reset),

    .EX_ALU_Result(alu_result),
    .EX_WriteData(ex_read_data2),
    .EX_rd(ex_rd),

    .RegWrite_in(RegWrite_EX),
    .MemRead_in(MemRead_EX),
    .MemWrite_in(MemWrite_EX),
    .MemtoReg_in(MemtoReg_EX),

    .MEM_ALU_Result(mem_alu_result),
    .MEM_WriteData(mem_write_data),
    .MEM_rd(mem_rd),

    .RegWrite_out(RegWrite_MEM),
    .MemRead_out(MemRead_MEM),
    .MemWrite_out(MemWrite_MEM),
    .MemtoReg_out(MemtoReg_MEM)
);

data_memory DM(
    .clk(clk),
    .MemRead(MemRead_MEM),
    .MemWrite(MemWrite_MEM),
    .address(mem_alu_result),
    .write_data(mem_write_data),
    .read_data(mem_read_data)
);

MEM_WB MEMWB(
    .clk(clk),
    .reset(reset),

    .MEM_ALU_Result(mem_alu_result),
    .MEM_ReadData(mem_read_data),
    .MEM_rd(mem_rd),

    .RegWrite_in(RegWrite_MEM),
    .MemtoReg_in(MemtoReg_MEM),

    .WB_ALU_Result(wb_alu_result),
    .WB_ReadData(wb_read_data),
    .WB_rd(wb_rd),

    .RegWrite_out(RegWrite_WB),
    .MemtoReg_out(MemtoReg_WB)
);
assign pc_out = pc;
assign instruction_out = id_instruction;
assign alu_result_out = alu_result;
endmodule