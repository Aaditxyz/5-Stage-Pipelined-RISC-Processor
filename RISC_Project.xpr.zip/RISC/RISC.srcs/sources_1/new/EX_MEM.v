`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 02.08.2026 22:49:25
// Design Name: 
// Module Name: EX_MEM
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module EX_MEM(
    input clk,
    input reset,

    input [31:0] EX_ALU_Result,
    input [31:0] EX_WriteData,
    input [4:0] EX_rd,

    input RegWrite_in,
    input MemRead_in,
    input MemWrite_in,
    input MemtoReg_in,

    output reg [31:0] MEM_ALU_Result,
    output reg [31:0] MEM_WriteData,
    output reg [4:0] MEM_rd,

    output reg RegWrite_out,
    output reg MemRead_out,
    output reg MemWrite_out,
    output reg MemtoReg_out
);

always @(posedge clk or posedge reset)
begin
    if(reset)
    begin
        MEM_ALU_Result <= 32'd0;
        MEM_WriteData <= 32'd0;
        MEM_rd <= 5'd0;

        RegWrite_out <= 1'b0;
        MemRead_out <= 1'b0;
        MemWrite_out <= 1'b0;
        MemtoReg_out <= 1'b0;
    end
    else
    begin
        MEM_ALU_Result <= EX_ALU_Result;
        MEM_WriteData <= EX_WriteData;
        MEM_rd <= EX_rd;

        RegWrite_out <= RegWrite_in;
        MemRead_out <= MemRead_in;
        MemWrite_out <= MemWrite_in;
        MemtoReg_out <= MemtoReg_in;
    end
end

endmodule
